<?php

namespace App\Controller\Admin;

use Cake\Event\Event;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use App\Model\Entity\Brand;
use App\Model\Entity\Product;
use Cake\Network\Exception\NotFoundException;


class PromotionsController extends AppController
{
    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        $this->Auth->allow('delete');
    }

    public function index(){
    	 $this->viewBuilder()->layout('/Admin/adminheader');
         $query = $this->Promotions->find('all');
         $this->set('promotions', $this->paginate($query));
         $this->set('_serialize', ['promotions']); 

       // echo "index page hereeeeeeeeeeeeeeeeeeeeeeeeeeeeyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"; 
        }  

        public function edit($id = null){
             $promotion = $this->Promotions->get($id,[
                'contain'=>[]
            ]); 
           $this->viewBuilder()->layout('/Admin/adminheader');
            if($this->request->is(['patch','post','put'])){
            $promotion = $this->Promotions->patchEntity($promotion,$this->request->data);
            if($this->Promotions->save($promotion)){
                $this->Flash->success(__('This user has been updated'));
                return $this->redirect(['action'=>'index']);
            }else{
                $this->Flash->error(__('This user could not be updated. Please, try again.'));
            }
         }

        $this->set(compact('promotion'));
        $this->set('_serialize',['promotion']);
     
        }

        public function delete($id = null)
            { //$this->loadModel('Products');
                $this->viewBuilder()->layout('/Admin/adminheader');
                 if (empty($id)) {
                throw new NotFoundException(__('Article not found'));
             }
                //$this->request->allowMethod(['post', 'delete']);


                $promotion = $this->Promotions->get($id);
                if ($this->Promotions->delete($promotion)) {
                    $this->Flash->success(__('The user has been deleted.'));
                } else {
                    $this->Flash->error(__('The user could not be deleted. Please, try again.'));
                }
                
                return $this->redirect(['action' => 'index']);
            }

         public function view($id = null){
        $this->viewBuilder()->layout('/Admin/adminheader');
     $promotion = $this->set('promotion',$this->Promotions->get($id));

      $this->set('_serialize', ['promotion']);  
    }


        

         public function promotions()
        {
        	$this->loadModel('Promotions');
        	$this->viewBuilder()->layout('/Admin/adminheader'); 
        		if ($this->request->is('post','put')) {
        				print_r($_POST);

				$promotion = $this->Promotions->newEntity();
         		
         		 $promotion = $this->Promotions->patchEntity($promotion, $_POST);
            	 $this->Promotions->save($promotion);
         		die();
         	}

        }
//____________________________To add promotion_______________________//

         public function add()
         {
                $this->loadModel('Products');
                $product = $this->Products->find('all');
                $data['product'] = $product->toArray();
         	if ($this->request->is('post','put')) {

               print_r($_POST);
				$promotion = $this->Promotions->newEntity();
         		
         		 $promotion = $this->Promotions->patchEntity($promotion, $_POST);
            	 if($this->Promotions->save($promotion))
                 {
                   $promo_id =  $promotion->id;  
                     for($j=0; $j<count($this->request->data['product_id']); $j++)
                    {
                        $pro $this->request->data['product_id'][$j];       

                    }

                 }
         		return $this->redirect(['action' => 'index']);
         	}
        $this->viewBuilder()->layout('/Admin/adminheader'); 
 			
        $this->loadModel('Settings');
        $setting_query =    $this->Settings->find(); 
        $setting_results = $setting_query->all();
        $data['setting'] = $setting_results->toArray();          
        $this->set(compact('data'));
        $this->set('_serialize', ['data']);
       	}
}
