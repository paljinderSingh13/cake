<?php

namespace App\Controller\Admin;

use Cake\Event\Event;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use App\Model\Entity\Productimage;
use App\Model\Entity\Brand;
use App\Model\Entity\Product;
use Cake\Network\Exception\NotFoundException;



class ProductsController extends AppController
{
      public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Flash');
        
    }



    public function beforeFilter(Event $event)
    {
     
        parent::beforeFilter($event);
        $this->Auth->allow('delete');
        $this->loadComponent('Flash');
    
    }

    public function index(){
    	 $this->viewBuilder()->layout('/Admin/adminheader');
         $query = $this->Products->find('all');
           $this->loadModel('Settings');
            $setting_query =    $this->Settings->find(); 
            $setting_results = $setting_query->all();
            $products->setting = $setting_results->toArray();


        $this->set(compact('products'));
        $this->set('_serialize', ['products']);

        die;
       // echo "index page hereeeeeeeeeeeeeeeeeeeeeeeeeeeeyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"; 
        }  

        public function edit($id = null){
            $this->loadModel('Productimages');
            $product = $this->Products->get($id,[
                'contain'=>['Productimages']
            ]);
        $product->toArray(); 
           $this->viewBuilder()->layout('/Admin/adminheader');
            if($this->request->is(['patch','post','put'])){
            $product = $this->Products->patchEntity($product,$this->request->data);
               if ($this->Products->save($product)) {
					$lastId = $id;
                    if($lastId>0){
                for($i=0; $i<count($this->request->data['product_image']); $i++){
				
						$one = $this->request->data['product_image'][$i];
				
	
						$this->request->data['product_image'] = time().$i .'.' . pathinfo($one['name'], PATHINFO_EXTENSION);
						
						if ($one['error'] == '0') {
							$pth2 =  WWW_ROOT.'img'.DS.'product' . DS . $this->request->data['product_image'];
							move_uploaded_file($one['tmp_name'], $pth2);
						}
                        $productImages['Productimages']['product_id']  = $lastId;
						$productImages['Productimages']['image'] = $this->request->data['product_image'];
						$productImages['Productimages']['status'] = 1;
                        pr($productImages);
                        pr($product->productimages);
                       
                        
                        $PI = $this->Productimages->patchEntity($product, $productImages);
						if($this->Productimages->save($PI)){
                                 $this->Flash->success(__('This product has been updated')); 
                        }else{
                                 $this->Flash->error(__('This product has not been updated')); 
                        }
				}
                    }
                    
               }else{
                          $this->Flash->error(__('This product has not been added')); 
 
               }
         }
              $this->loadModel('Settings');
            $setting_query =    $this->Settings->find(); 
            $setting_results = $setting_query->all();
            $data['setting'] = $setting_results->toArray();
            
             $this->loadModel('Brands');
            $query =    $this->Brands->find(); //'all',array('fields'=>array('id','brand_name'))
            $results = $query->all();
            $brands = $results->toArray();
            $en =  json_encode($brands);
            $product['brands'] = json_decode($en);

            $this->loadModel('cartridges');
            $cart_query = $this->cartridges->find(); //'all',array('fields'=>array('id','brand_name'))
            $cart_results = $cart_query->all();
            $cartridges = $cart_results->toArray();
            $cart_en =  json_encode($cartridges);
            $product['carts'] = json_decode($cart_en);
            
    $this->set(compact('product'));
    $this->set('_serialize',['product']);
     
        }

        public function delete($id = null)
            { //$this->loadModel('Products');
                $this->viewBuilder()->layout('/Admin/adminheader');
                 if (empty($id)) {
        throw new NotFoundException(__('Article not found'));
    }
                //$this->request->allowMethod(['post', 'delete']);


                $product = $this->Products->get($id);
                if ($this->Products->delete($product)) {
                    $this->Flash->success(__('The user has been deleted.'));
                } else {
                    $this->Flash->error(__('The user could not be deleted. Please, try again.'));
                }
                
                return $this->redirect(['action' => 'index']);
            }

         public function view($id = null){
        $this->viewBuilder()->layout('/Admin/adminheader');
    $products= $this->set('products',$this->Products->get($id));

      $this->set('_serialize', ['products']);  
    }


        public function gifts()
        {
        	//print_r($_POST); 
        	
        	$this->loadModel('Gifts');
        	$this->viewBuilder()->layout('/Admin/adminheader'); 
        		if ($this->request->is('post','put')) {
        				print_r($_POST);

				$gift = $this->Gifts->newEntity();
         		
         		 $gift = $this->Gifts->patchEntity($gift, $_POST);
            	 if($this->Gifts->save($gift))
                 {
                        echo "product add successfully";
                 }
         		die();
         	}

        }

         public function promotions()
        {
        	$this->loadModel('Promotions');
        	$this->viewBuilder()->layout('/Admin/adminheader'); 
        		if ($this->request->is('post','put')) {
        				print_r($_POST);

				$promotion = $this->Promotions->newEntity();
         		
         		 $promotion = $this->Promotions->patchEntity($promotion, $_POST);
            	 $this->Promotions->save($promotion);
         		die();
                }

        }

         public function add()
         {
           $this->loadModel('Productimages');
            $this->viewBuilder()->layout('/Admin/adminheader'); 

           // $this->Productimages->save(array('product_id'=>58,'image'=>'image.jpg','status'=>1));
            
         	if ($this->request->is('post','put')) {
				$product = $this->Products->newEntity();
         		 $product = $this->Products->patchEntity($product, $_POST);      
               if ($this->Products->save($product)) {
					$lastId = $product->id;
                    if($lastId>0){
                for($i=0; $i<count($this->request->data['product_image']); $i++){
				
						$one2 = $this->request->data['product_image'][$i];
				
	
						$this->request->data['product_image'] = time().$i .'.' . pathinfo($one2['name'], PATHINFO_EXTENSION);
						
						if ($one2['error'] == '0') {
							$pth2 =  WWW_ROOT.'img'.DS.'product' . DS . $this->request->data['product_image'];
							move_uploaded_file($one2['tmp_name'], $pth2);
						}
                        $productImages['Productimages']['product_id']  = $lastId;
						$productImages['Productimages']['image'] = $this->request->data['product_image'];
						$productImages['Productimages']['status'] = 1;
                      
                         $PI = $this->Productimages->newEntity();
                        $PI = $this->Productimages->patchEntity($PI, $productImages);
						if($this->Productimages->save($PI)){
                                 $this->Flash->success(__('This product has been added')); 
                        }else{
                                 $this->Flash->error(__('This product has not been added')); 
                        }
				}
                    }
                    
               }
         		
         	}
        
			$this->viewBuilder()->layout('/Admin/adminheader'); 
 			$this->loadModel('Brands');
 			$query =$this->Brands->find(); //'all',array('fields'=>array('id','brand_name'))
 			$results = $query->all();
 			$brands = $results->toArray();
			$en =  json_encode($brands);
        	$data['brands'] = json_decode($en);

        	$this->loadModel('cartridges');
        	$cart_query = $this->cartridges->find(); //'all',array('fields'=>array('id','brand_name'))
 			$cart_results = $cart_query->all();
 			$cartridges = $cart_results->toArray();
			$cart_en =  json_encode($cartridges);
        	$data['carts'] = json_decode($cart_en);
        // print_r($data);
        // die;
         	// foreach ($de as  $value) {

         	// 	echo $value->id;
         	// 	//echo $value_properties:protected']['name'];
         	// }
          
		$this->set(compact('data'));
        	$this->set('_serialize', ['data']);
       	}
}
