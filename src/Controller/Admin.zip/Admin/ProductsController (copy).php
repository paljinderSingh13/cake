<?php

namespace App\Controller\Admin;

use Cake\Event\Event;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use App\Model\Entity\Brand;
use App\Model\Entity\Product;
use Cake\Network\Exception\NotFoundException;


class ProductsController extends AppController
{
    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        $this->Auth->allow('delete');
    }

    public function index(){
    	 $this->viewBuilder()->layout('/Admin/adminheader');
         $query = $this->Products->find('all');
        $products = $this->paginate($query);

         $this->loadModel('Settings');
            $setting_query =    $this->Settings->find(); 
            $setting_results = $setting_query->all();
            $products->setting = $setting_results->toArray();


        $this->set(compact('products'));
        $this->set('_serialize', ['products']);

        }  

         public function edit($id = null){


       
            $this->loadModel('Productimages');
            $product = $this->Products->get($id,[
                'contain'=>['Productimages']
            ]);
        $product->toArray(); 
           $this->viewBuilder()->layout('/Admin/adminheader');
            if($this->request->is(['patch','post','put'])){
            $product_update = $this->Products->patchEntity($product,$this->request->data);
               if ($this->Products->save($product_update)) {
                    $lastId = $id;
                    if($lastId>0){
                for($i=0; $i<count($this->request->data['product_image']); $i++){
                
                        $one = $this->request->data['product_image'][$i];
                
    
                        $this->request->data['product_image'] = time().$i .'.' . pathinfo($one['name'], PATHINFO_EXTENSION);
                        
                        if ($one['error'] == '0') {
                            $pth2 =  WWW_ROOT.'img'.DS.'product' . DS . $this->request->data['product_image'];
                            move_uploaded_file($one['tmp_name'], $pth2);
                        }
                        $productImages['Productimages']['product_id']  = $lastId;
                        $productImages['Productimages']['image'] = $this->request->data['product_image'];
                        $productImages['Productimages']['status'] = 1;
                        pr($productImages);
                       pr($product->productimages);
                     exit;
                        
                        $PI = $this->Productimages->patchEntity($product->productimages, $productImages);
                        if($this->Productimages->save($PI)){
                                 $this->Flash->success(__('This product has been updated')); 
                        }else{
                                 $this->Flash->error(__('This product has not been updated')); 
                        }
                }
                    }
                    
               }else{
                          $this->Flash->error(__('This product has not been added')); 
 
               }
         }
              $this->loadModel('Settings');
            $setting_query =    $this->Settings->find(); 
            $setting_results = $setting_query->all();
            $product['setting'] = $setting_results->toArray();
            
            
            
    $this->set(compact('product'));
    $this->set('_serialize',['product']);
     
        }

        

        public function delete($id = null)
            { 
                $this->viewBuilder()->layout('/Admin/adminheader');
                 if (empty($id)) {
                        throw new NotFoundException(__('Article not found'));
                        }
              $product = $this->Products->get($id);
                if ($this->Products->delete($product)) {
                    $this->Flash->success(__('The Product has been deleted.'));
                } else {
                    $this->Flash->error(__('The Product could not be deleted. Please, try again.'));
                }
                
                return $this->redirect(['action' => 'index']);
            }

        public function view($id = null)
        {
            $this->viewBuilder()->layout('/Admin/adminheader');
          
           $products = $this->Products->get($id ,[
                    'contain'=>['Productimages']
                ]);

            $this->set(compact('products'));
            $this->set('_serialize', ['products']);  
        }

        public function add()
         {
            $this->loadModel('Productimages');

         	if ($this->request->is('post','put')) {
				$product = $this->Products->newEntity();
         		$product = $this->Products->patchEntity($product, $_POST);
            	if ($this->Products->save($product)) {
                    $lastId = $product->id;
                    if($lastId>0){
                for($i=0; $i<count($this->request->data['product_image']); $i++){
                
                        $one2 = $this->request->data['product_image'][$i];
                $this->request->data['product_image'] = time().$i .'.' . pathinfo($one2['name'], PATHINFO_EXTENSION);
                        
                        if ($one2['error'] == '0') {
                            $pth2 =  WWW_ROOT.'img'.DS.'product' . DS . $this->request->data['product_image'];
                            move_uploaded_file($one2['tmp_name'], $pth2);
                        }
                        $productImages['Productimages']['product_id']  = $lastId;
                        $productImages['Productimages']['image'] = $this->request->data['product_image'];
                        $productImages['Productimages']['status'] = 1;
                      
                         $PI = $this->Productimages->newEntity();
                        $PI = $this->Productimages->patchEntity($PI, $productImages);
                        if($this->Productimages->save($PI)){
                                 $this->Flash->success(__('This product has been added')); 
                        }else{
                                 $this->Flash->error(__('This product has not been added')); 
                        }
                }
                    }
                    
               }
         		return $this->redirect(['action' => 'index']);
         	}
        
			$this->viewBuilder()->layout('/Admin/adminheader'); 

            $this->loadModel('Settings');
            $setting_query =    $this->Settings->find(); 
            $setting_results = $setting_query->all();
            $data['setting'] = $setting_results->toArray();

 			$this->loadModel('Brands');
 			$query =	$this->Brands->find(); //'all',array('fields'=>array('id','brand_name'))
 			$results = $query->all();
 			$brands = $results->toArray();
			$en =  json_encode($brands);
        	$data['brands'] = json_decode($en);

        	$this->loadModel('cartridges');
        	$cart_query = $this->cartridges->find(); //'all',array('fields'=>array('id','brand_name'))
 			$cart_results = $cart_query->all();
 			$cartridges = $cart_results->toArray();
			$cart_en =  json_encode($cartridges);
        	$data['carts'] = json_decode($cart_en);
        
          
		$this->set(compact('data'));
        	$this->set('_serialize', ['data']);
       	}
}
